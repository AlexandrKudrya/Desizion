# Инструкция для Claude Code

Привет! Это подробная инструкция по реализации MVP DecisionMatrix.

## Что уже сделано

✅ Архитектура спроектирована
✅ Структура папок с README.md
✅ TypeScript типы описаны
✅ Логика нормализации расписана
✅ Store архитектура определена
✅ Компоненты спланированы

## Что нужно реализовать

### Этап 1: Базовая настройка (30 мин)

1. **Инициализация проекта**
```bash
npm create vite@latest decision-matrix -- --template react-ts
cd decision-matrix
npm install
```

2. **Установка зависимостей**
```bash
# Основные
npm install zustand react-hook-form zod @hookform/resolvers uuid

# UI библиотеки
npm install clsx tailwind-merge class-variance-authority lucide-react

# Radix UI (для shadcn/ui)
npm install @radix-ui/react-dialog @radix-ui/react-select @radix-ui/react-tabs @radix-ui/react-slot @radix-ui/react-label @radix-ui/react-alert-dialog

# Dev зависимости
npm install -D @types/uuid tailwindcss postcss autoprefixer
```

3. **Настройка Tailwind**
```bash
npx tailwindcss init -p
```

Обнови `tailwind.config.js`:
```js
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

Создай `src/index.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

4. **Настройка path aliases**

В `vite.config.ts`:
```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

В `tsconfig.json` добавь:
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

5. **Установка shadcn/ui**
```bash
npx shadcn-ui@latest init
```

Установи нужные компоненты:
```bash
npx shadcn-ui@latest add button
npx shadcn-ui@latest add input
npx shadcn-ui@latest add select
npx shadcn-ui@latest add dialog
npx shadcn-ui@latest add table
npx shadcn-ui@latest add card
npx shadcn-ui@latest add tabs
npx shadcn-ui@latest add form
npx shadcn-ui@latest add slider
npx shadcn-ui@latest add badge
npx shadcn-ui@latest add alert-dialog
```

### Этап 2: Типы и утилиты (1 час)

**Файл**: `src/types/index.ts`

Реализуй все типы как описано в `src/types/README.md`:
- `NormalizationType` enum
- `NormalizationParams` union type
- `CategoryMapping` interface
- `Criterion` interface
- `Alternative` interface
- `Project` interface

**Файл**: `src/lib/utils.ts`

```typescript
import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { v4 as uuidv4 } from 'uuid'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generateId(): string {
  return uuidv4()
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date)
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max)
}
```

**Файл**: `src/lib/normalization.ts`

Реализуй все функции нормализации как описано в `src/lib/README.md`:
- `normalizeLinear`
- `normalizeInverseLinear`
- `normalizeThreshold`
- `normalizeExponential`
- `normalizeCategorical`
- `normalize` (главная функция-диспетчер)

**Файл**: `src/lib/calculations.ts`

Реализуй функции расчёта:
- `calculateNormalizedScores`
- `calculateTotalScore`
- `rankAlternatives`

**Файл**: `src/lib/storage.ts`

Реализуй функции работы с localStorage:
- `saveProjects`
- `loadProjects`
- `exportProject`
- `importProject`

**Файл**: `src/lib/validation.ts`

Создай Zod схемы:
- `NormalizationParamsSchema` (discriminated union)
- `CriterionSchema`
- `AlternativeSchema`
- `ProjectSchema`

### Этап 3: Store (1.5 часа)

**Файл**: `src/store/index.ts`

Реализуй Zustand store как описано в `src/store/README.md`.

Структура:
```typescript
interface AppState {
  // Data
  projects: Project[]
  currentProjectId: string | null
  
  // Project actions
  createProject: (name: string, description?: string) => void
  deleteProject: (id: string) => void
  updateProject: (id: string, updates: Partial<Project>) => void
  setCurrentProject: (id: string | null) => void
  
  // Criterion actions
  addCriterion: (projectId: string, criterion: Omit<Criterion, 'id'>) => void
  updateCriterion: (projectId: string, id: string, updates: Partial<Criterion>) => void
  deleteCriterion: (projectId: string, id: string) => void
  
  // Alternative actions
  addAlternative: (projectId: string, alt: Omit<Alternative, 'id'>) => void
  updateAlternative: (projectId: string, id: string, updates: Partial<Alternative>) => void
  deleteAlternative: (projectId: string, id: string) => void
  
  // Calculations
  recalculateScores: (projectId: string) => void
  
  // Import/Export
  exportProject: (projectId: string) => string
  importProject: (jsonString: string) => void
}
```

Используй middleware:
- `persist` для localStorage
- `devtools` для дебага

### Этап 4: UI компоненты (3-4 часа)

Реализуй компоненты в порядке приоритета:

#### 4.1 Layout компоненты

**`src/components/layout/Header.tsx`**
```tsx
export function Header() {
  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">DecisionMatrix</h1>
        {/* кнопки */}
      </div>
    </header>
  )
}
```

**`src/components/layout/Sidebar.tsx`**
- Список проектов
- Активный проект подсвечен
- Кнопка создания

**`src/components/layout/Layout.tsx`**
- Обёртка с Header + Sidebar + main

#### 4.2 Проектные компоненты

**`src/components/project/ProjectList.tsx`**
- Список карточек проектов
- Кнопка создания нового

**`src/components/project/ProjectCard.tsx`**
- Карточка с названием, датой, кнопками

**`src/components/project/ProjectHeader.tsx`**
- Шапка открытого проекта
- Экспорт/импорт

#### 4.3 Критерии

**`src/components/criteria/CriteriaList.tsx`**
- Таблица критериев
- Сумма весов в футере

**`src/components/criteria/CriterionDialog.tsx`**
- Форма создания/редактирования
- Динамические поля параметров

**`src/components/criteria/NormalizationParamsInput.tsx`**
- Switch по типу нормализации
- Рендерит соответствующие поля

**`src/components/criteria/CategoryMappingTable.tsx`**
- Таблица категорий для категориальных критериев

#### 4.4 Альтернативы

**`src/components/alternatives/AlternativesTable.tsx`**
- Таблица с динамическими столбцами
- Inline редактирование

**`src/components/alternatives/AlternativeDialog.tsx`**
- Форма альтернативы
- Поля для всех критериев

**`src/components/alternatives/CriterionValueInput.tsx`**
- Динамическое поле в зависимости от типа критерия

#### 4.5 Результаты

**`src/components/results/RankingTable.tsx`**
- Таблица с рейтингом
- Медали для топ-3
- Прогресс-бары

**`src/components/results/AlternativeDetails.tsx`**
- Детальная карточка
- Разбивка по критериям

**`src/components/results/ScoreBreakdown.tsx`**
- Таблица вклада каждого критерия

### Этап 5: Страницы (1 час)

**`src/App.tsx`**
```tsx
function App() {
  const currentProjectId = useStore(state => state.currentProjectId)
  
  return (
    <Layout>
      {currentProjectId ? <ProjectPage /> : <HomePage />}
    </Layout>
  )
}
```

**`src/pages/HomePage.tsx`**
- Список проектов
- Приветствие для нового пользователя

**`src/pages/ProjectPage.tsx`**
- Вкладки: Критерии | Альтернативы | Результаты
- Рендерит соответствующие компоненты

### Этап 6: Полировка (1-2 часа)

1. **Валидация весов**
   - Проверка что сумма = 1.0
   - Визуальный индикатор

2. **Подтверждения удаления**
   - AlertDialog для критичных действий

3. **Пустые состояния**
   - "Нет проектов" → призыв создать
   - "Нет критериев" → призыв добавить

4. **Адаптивность**
   - Проверь на мобилке
   - Таблицы → карточки на маленьких экранах

5. **Экспорт/импорт JSON**
   - Скачивание файла
   - Загрузка через input[type=file]

## Приоритизация

**Must have (MVP)**:
- ✅ Создание проектов
- ✅ CRUD критериев с весами
- ✅ Все 5 типов нормализации
- ✅ CRUD альтернатив
- ✅ Автоматический расчёт рейтинга
- ✅ Таблица результатов
- ✅ Экспорт/импорт JSON

**Nice to have (v1.1)**:
- ⏭️ Графики
- ⏭️ Шаблоны проектов
- ⏭️ Экспорт в Excel
- ⏭️ Сравнение side-by-side

## Советы по реализации

### 1. Начни с данных
Сначала реализуй типы, store, утилиты. Протестируй их отдельно.

### 2. UI по слоям
Не делай все компоненты сразу. Сначала базовый flow:
1. Создание проекта
2. Добавление критерия
3. Добавление альтернативы
4. Просмотр результатов

Потом добавляй редактирование, удаление, детали.

### 3. Используй React DevTools
Следи за ре-рендерами. Zustand хорошо оптимизирован, но стоит проверять.

### 4. Тестируй по ходу
Каждый раз когда добавляешь функцию нормализации - проверь её вручную с разными значениями.

### 5. Incremental commits
Коммить после каждого этапа:
- "feat: add types and utils"
- "feat: implement normalization functions"
- "feat: create zustand store"
- "feat: add criteria components"
- etc.

## Проверочный список

- [ ] Проект создаётся
- [ ] Критерий добавляется с весом
- [ ] Все 5 типов нормализации работают
- [ ] Сумма весов = 100%
- [ ] Альтернатива добавляется
- [ ] Рейтинг рассчитывается правильно
- [ ] Результаты сортируются
- [ ] Экспорт в JSON работает
- [ ] Импорт из JSON работает
- [ ] Данные сохраняются в localStorage
- [ ] После перезагрузки данные восстанавливаются
- [ ] Работает на мобилке

## Запуск

```bash
npm run dev
```

Открой http://localhost:5173

## Деплой

После завершения:
```bash
npm run build
```

Деплой на Vercel:
```bash
npx vercel
```

## Вопросы?

Если что-то непонятно - обращайся. Все детали расписаны в README.md каждой папки.

Удачи! 🚀
