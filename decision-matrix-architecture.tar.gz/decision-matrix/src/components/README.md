# src/components

React компоненты приложения.

## Структура

```
components/
├── ui/              # Базовые UI компоненты (shadcn/ui)
├── layout/          # Компоненты лейаута (Header, Sidebar)
├── project/         # Компоненты для работы с проектами
├── criteria/        # Компоненты для критериев
├── alternatives/    # Компоненты для альтернатив
└── results/         # Компоненты отображения результатов
```

## Компоненты по папкам

### `ui/` - Базовые UI компоненты

**Источник**: shadcn/ui (устанавливаются через CLI)

Компоненты:
- `Button.tsx` - Кнопки
- `Input.tsx` - Текстовые поля
- `Select.tsx` - Выпадающие списки
- `Dialog.tsx` - Модальные окна
- `Table.tsx` - Таблицы
- `Card.tsx` - Карточки
- `Badge.tsx` - Бейджи
- `Tabs.tsx` - Вкладки
- `Form.tsx` - Формы (с react-hook-form)
- `Slider.tsx` - Слайдеры для весов
- `Alert.tsx` - Уведомления

**Установка**:
```bash
npx shadcn-ui@latest add button
npx shadcn-ui@latest add input
# и т.д.
```

**Стили**: Tailwind CSS (настроены в `tailwind.config.js`)

---

### `layout/` - Компоненты лейаута

#### `Header.tsx`
Шапка приложения.

**Props**: нет

**Содержимое**:
- Логотип / название "DecisionMatrix"
- Кнопка "Новый проект"
- (future) Меню пользователя

**Пример**:
```tsx
<Header />
```

#### `Sidebar.tsx`
Боковая панель со списком проектов.

**Props**:
```typescript
{
  projects: Project[]
  currentProjectId: string | null
  onSelectProject: (id: string) => void
  onCreateProject: () => void
}
```

**Содержимое**:
- Список проектов (кликабельный)
- Кнопка "+ Новый проект"
- Индикатор активного проекта

#### `Layout.tsx`
Главный layout с Header + Sidebar + Content.

**Props**:
```typescript
{
  children: ReactNode
}
```

**Структура**:
```tsx
<Layout>
  <Header />
  <div className="flex">
    <Sidebar />
    <main>{children}</main>
  </div>
</Layout>
```

---

### `project/` - Проекты

#### `ProjectList.tsx`
Список всех проектов (для главной страницы).

**Props**: нет (берёт из store)

**Функционал**:
- Карточки проектов с названием, датой
- Кнопка "Открыть"
- Кнопка "Удалить" (с подтверждением)
- Кнопка "Создать новый"

#### `ProjectCard.tsx`
Карточка одного проекта.

**Props**:
```typescript
{
  project: Project
  onClick: () => void
  onDelete: () => void
}
```

**Отображает**:
- Название
- Описание (если есть)
- Дата создания
- Количество критериев/альтернатив

#### `ProjectHeader.tsx`
Шапка открытого проекта.

**Props**:
```typescript
{
  project: Project
  onEdit: () => void
  onExport: () => void
  onImport: () => void
}
```

**Функционал**:
- Название проекта (редактируемое)
- Кнопки: Экспорт JSON, Импорт JSON
- Кнопка "Назад к проектам"

---

### `criteria/` - Критерии

#### `CriteriaList.tsx`
Таблица критериев.

**Props**:
```typescript
{
  criteria: Criterion[]
  onAdd: () => void
  onEdit: (id: string) => void
  onDelete: (id: string) => void
}
```

**Столбцы таблицы**:
- Название
- Вес (с процентами)
- Тип нормализации
- Действия (Редактировать, Удалить)

**Футер**: Сумма весов (с индикатором 100% ✓/✗)

#### `CriterionDialog.tsx`
Модальное окно для создания/редактирования критерия.

**Props**:
```typescript
{
  criterion?: Criterion  // undefined для создания
  open: boolean
  onClose: () => void
  onSave: (criterion: Omit<Criterion, 'id'>) => void
}
```

**Поля формы**:
- Название (text input)
- Вес (slider 0-100% или number input)
- Тип нормализации (select)
- Параметры (динамические, зависят от типа):
  - LINEAR: min, max
  - INVERSE_LINEAR: min, max, threshold
  - THRESHOLD: min, max, threshold1
  - EXPONENTIAL: min, max, threshold1, threshold2
  - CATEGORICAL: таблица категорий
- Описание (textarea)

**Валидация**:
- React Hook Form + Zod
- Проверка: название не пустое, вес 0-100, параметры валидны

#### `NormalizationParamsInput.tsx`
Динамические поля параметров нормализации.

**Props**:
```typescript
{
  normType: NormalizationType
  params: NormalizationParams
  onChange: (params: NormalizationParams) => void
}
```

**Рендерит разные поля** в зависимости от `normType`:
```tsx
switch (normType) {
  case 'LINEAR':
    return <MinMaxInputs />
  case 'THRESHOLD':
    return <ThresholdInputs />
  // и т.д.
}
```

#### `CategoryMappingTable.tsx`
Таблица категорий для категориальных критериев.

**Props**:
```typescript
{
  categories: CategoryMapping[]
  onChange: (categories: CategoryMapping[]) => void
}
```

**Функционал**:
- Список категорий (label + value)
- Кнопка "+ Добавить категорию"
- Удаление категории
- Редактирование inline

---

### `alternatives/` - Альтернативы

#### `AlternativesTable.tsx`
Таблица альтернатив с динамическими столбцами.

**Props**:
```typescript
{
  alternatives: Alternative[]
  criteria: Criterion[]
  onAdd: () => void
  onEdit: (id: string) => void
  onDelete: (id: string) => void
}
```

**Столбцы**:
- № (порядковый номер)
- Название
- Столбец для каждого критерия (динамически)
- Действия

**Ячейки**:
- Для числовых: `<input type="number">`
- Для категориальных: `<select>` из справочника
- Редактирование inline

#### `AlternativeDialog.tsx`
Модальное окно для альтернативы.

**Props**:
```typescript
{
  alternative?: Alternative
  criteria: Criterion[]
  open: boolean
  onClose: () => void
  onSave: (alternative: Omit<Alternative, 'id'>) => void
}
```

**Поля**:
- Название
- Описание (опционально)
- Оценки по каждому критерию (динамически)

#### `CriterionValueInput.tsx`
Поле ввода значения для критерия.

**Props**:
```typescript
{
  criterion: Criterion
  value: any
  onChange: (value: any) => void
}
```

**Рендерит** в зависимости от типа:
- Числовые критерии → `<Input type="number">`
- Категориальные → `<Select>` из categories

---

### `results/` - Результаты

#### `RankingTable.tsx`
Таблица с рейтингом альтернатив.

**Props**:
```typescript
{
  alternatives: Alternative[]
  criteria: Criterion[]
  showNormalized: boolean
}
```

**Столбцы**:
- Место (🥇🥈🥉 для топ-3)
- Название
- Рейтинг (с прогресс-баром)
- % от идеала
- (опционально) Нормализованные значения

**Сортировка**: По убыванию totalScore

#### `AlternativeDetails.tsx`
Детальная карточка альтернативы.

**Props**:
```typescript
{
  alternative: Alternative
  criteria: Criterion[]
}
```

**Отображает**:
- Название, описание
- Итоговый рейтинг (крупно)
- Таблица: Критерий | Значение | Нормализованное | Взвешенное
- Визуализация вклада каждого критерия (прогресс-бары)

#### `ScoreBreakdown.tsx`
Разбивка рейтинга по критериям.

**Props**:
```typescript
{
  alternative: Alternative
  criteria: Criterion[]
}
```

**Отображает**:
- Для каждого критерия:
  - Название
  - Исходное значение
  - Нормализованное (0-1)
  - Вес критерия
  - Взвешенное значение (contribution)
  - Прогресс-бар

---

## Общие паттерны

### Композиция

Компоненты построены по принципу композиции:
```tsx
<ProjectPage>
  <ProjectHeader />
  <Tabs>
    <TabPanel label="Критерии">
      <CriteriaList />
    </TabPanel>
    <TabPanel label="Альтернативы">
      <AlternativesTable />
    </TabPanel>
    <TabPanel label="Результаты">
      <RankingTable />
    </TabPanel>
  </Tabs>
</ProjectPage>
```

### Props типизация

Все props типизированы через TypeScript интерфейсы:
```typescript
interface CriteriaListProps {
  criteria: Criterion[]
  onAdd: () => void
  onEdit: (id: string) => void
  onDelete: (id: string) => void
}
```

### Работа со store

Компоненты получают данные из store через хуки:
```tsx
const criteria = useStore(state => 
  state.projects.find(p => p.id === currentId)?.criteria ?? []
)
const addCriterion = useStore(state => state.addCriterion)
```

### Формы

Используем React Hook Form:
```tsx
const form = useForm<CriterionFormData>({
  resolver: zodResolver(criterionSchema),
  defaultValues: criterion
})

const onSubmit = (data: CriterionFormData) => {
  onSave(data)
  form.reset()
}

return (
  <Form {...form}>
    <form onSubmit={form.handleSubmit(onSubmit)}>
      {/* поля */}
    </form>
  </Form>
)
```

### Диалоги

Используем shadcn/ui Dialog:
```tsx
<Dialog open={open} onOpenChange={onClose}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Добавить критерий</DialogTitle>
    </DialogHeader>
    {/* форма */}
    <DialogFooter>
      <Button onClick={onClose}>Отмена</Button>
      <Button type="submit">Сохранить</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

## Стилизация

- **Tailwind utility classes** для базовой стилизации
- **shadcn/ui** компоненты уже стилизованы
- **Темизация** через CSS переменные (см. `globals.css`)

Пример:
```tsx
<div className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
  {/* контент */}
</div>
```

## Адаптивность

- Mobile-first подход
- Брейкпоинты Tailwind: `sm:`, `md:`, `lg:`, `xl:`
- Таблицы: на мобилках карточки, на десктопе таблица

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
  {/* карточки */}
</div>
```

## Для AI-ассистентов

- Компоненты функциональные (не классовые)
- Хуки на верхнем уровне
- Props деструктурируются в параметрах
- Используем early returns для guard clauses
- TypeScript типы для всех props
- JSDoc комментарии для сложной логики

## Пример полного компонента

```tsx
import { useState } from 'react'
import { useStore } from '@/store'
import { Button } from '@/components/ui/Button'
import { CriterionDialog } from './CriterionDialog'
import type { Criterion } from '@/types'

interface CriteriaListProps {
  projectId: string
}

export function CriteriaList({ projectId }: CriteriaListProps) {
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  
  const criteria = useStore(state => 
    state.projects.find(p => p.id === projectId)?.criteria ?? []
  )
  const addCriterion = useStore(state => state.addCriterion)
  const updateCriterion = useStore(state => state.updateCriterion)
  const deleteCriterion = useStore(state => state.deleteCriterion)
  
  const handleSave = (data: Omit<Criterion, 'id'>) => {
    if (editingId) {
      updateCriterion(projectId, editingId, data)
    } else {
      addCriterion(projectId, data)
    }
    setDialogOpen(false)
    setEditingId(null)
  }
  
  return (
    <div>
      <Button onClick={() => setDialogOpen(true)}>
        + Добавить критерий
      </Button>
      
      {/* таблица критериев */}
      
      <CriterionDialog
        open={dialogOpen}
        criterion={criteria.find(c => c.id === editingId)}
        onClose={() => {
          setDialogOpen(false)
          setEditingId(null)
        }}
        onSave={handleSave}
      />
    </div>
  )
}
```
