# src/lib

Библиотека утилит, хелперов и чистых функций.

## Файлы

### `normalization.ts`
**Назначение**: Функции нормализации значений критериев в диапазон [0, 1].

**Функции:**

#### `normalizeLinear(value, min, max): number`
Линейная нормализация. Чем больше значение, тем лучше.

**Формула**: `(value - min) / (max - min)`

**Пример**: 
- Критерий "Площадь кухни" (6-14 кв.м)
- 10 кв.м → (10-6)/(14-6) = 0.5

#### `normalizeInverseLinear(value, min, max, threshold): number`
Обратная линейная. Чем меньше значение, тем лучше.

**Логика**:
- До threshold → 1.0 (идеально)
- После threshold → линейное падение до 0

**Формула**: 
```
if value <= threshold: 1.0
else: max(0, (max - value) / (max - threshold))
```

**Пример**:
- Критерий "Расстояние до метро" (0-15 мин)
- Threshold = 5 мин
- 3 мин → 1.0
- 10 мин → (15-10)/(15-5) = 0.5

#### `normalizeThreshold(value, min, max, threshold1): number`
Пороговая нормализация с критической границей.

**Логика**:
- value ≤ threshold1 → 1.0 (идеально)
- threshold1 < value ≤ max → линейное падение 1.0 → 0.5
- value > max → 0 (неприемлемо)

**Формула**:
```
if value <= threshold1: 1.0
else if value > max: 0
else: 1 - (value - threshold1) / (max - threshold1)
```

**Пример**:
- Критерий "Цена" (бюджет 40-50k, идеал 45k)
- 42k → 1.0
- 47k → 1 - (47-45)/(50-45) = 0.6
- 55k → 0

#### `normalizeExponential(value, min, max, threshold1, k): number`
Экспоненциальная нормализация с убывающей важностью.

**Логика**:
- До threshold1 → 1.0
- После threshold1 → exp(-k * (value - threshold1))

**Формула**:
```
if value <= threshold1: 1.0
else: exp(-k * (value - threshold1))
```

**Пример**:
- Критерий "Время в пути" (0-60 мин, комфорт до 30 мин, k=0.05)
- 25 мин → 1.0
- 40 мин → exp(-0.05 * 10) ≈ 0.606
- 60 мин → exp(-0.05 * 30) ≈ 0.223

#### `normalizeCategorical(value, categories): number`
Категориальная нормализация (маппинг на фиксированные значения).

**Логика**: Поиск соответствия label → value из справочника

**Пример**:
- Критерий "Балкон"
- Categories: {"Большой": 1.0, "Обычный": 0.7, "Маленький": 0.4, "Нет": 0}
- "Обычный" → 0.7

#### `normalize(value, criterion): number`
**Главная функция**. Диспетчер, выбирает нужную нормализацию по типу критерия.

**Использование**:
```typescript
import { normalize } from '@/lib/normalization'

const normalizedValue = normalize(42000, criterion)
```

---

### `storage.ts`
**Назначение**: Работа с localStorage для сохранения проектов.

**Функции:**

#### `saveProjects(projects: Project[]): void`
Сохраняет все проекты в localStorage.

**Ключ**: `'decision-matrix-projects'`

**Формат**: JSON.stringify

#### `loadProjects(): Project[]`
Загружает проекты из localStorage.

**Возвращает**: Массив проектов или [] если пусто.

**Обработка ошибок**: При невалидном JSON возвращает пустой массив.

#### `exportProject(project: Project): string`
Экспортирует проект в JSON строку для скачивания.

**Возвращает**: Prettified JSON (с отступами).

#### `importProject(jsonString: string): Project`
Импортирует проект из JSON.

**Throws**: Error если JSON невалиден или не соответствует схеме.

**Валидация**: Использует Zod схему (см. validation.ts).

---

### `calculations.ts`
**Назначение**: Расчёт рейтингов альтернатив.

**Функции:**

#### `calculateNormalizedScores(alternative, criteria): Record<string, number>`
Нормализует все оценки альтернативы.

**Логика**:
- Для каждого критерия берём значение из `alternative.values`
- Применяем нормализацию через `normalize()`
- Возвращаем объект `{ criterionId: normalizedScore }`

#### `calculateTotalScore(alternative, criteria): number`
Рассчитывает взвешенный итоговый рейтинг.

**Формула**: 
```
totalScore = Σ (normalizedScore[i] * weight[i])
```

где i - индекс критерия.

**Примечание**: Пропускает критерии без значения (undefined/null).

#### `rankAlternatives(alternatives, criteria): Alternative[]`
Сортирует альтернативы по убыванию рейтинга.

**Возвращает**: Новый массив (не мутирует оригинал).

**Использование**:
```typescript
import { rankAlternatives } from '@/lib/calculations'

const ranked = rankAlternatives(project.alternatives, project.criteria)
// ranked[0] - лучшая альтернатива
```

---

### `validation.ts`
**Назначение**: Zod схемы для валидации данных.

**Схемы:**

#### `CriterionSchema`
Валидация критерия.

**Правила**:
- `id`: непустая строка
- `name`: непустая строка
- `weight`: число от 0 до 1
- `normType`: один из enum NormalizationType
- `params`: объект (структура зависит от normType)

#### `AlternativeSchema`
Валидация альтернативы.

#### `ProjectSchema`
Валидация всего проекта.

**Кастомные проверки**:
- Сумма весов критериев ≈ 1.0 (допуск ±0.01)
- Уникальность ID

**Использование**:
```typescript
import { ProjectSchema } from '@/lib/validation'

try {
  const validProject = ProjectSchema.parse(data)
} catch (error) {
  // Обработка ошибок валидации
}
```

---

### `utils.ts`
**Назначение**: Разные вспомогательные функции.

**Функции:**

#### `generateId(): string`
Генерирует UUID v4.

**Использование**: Для создания ID проектов, критериев, альтернатив.

#### `cn(...inputs): string`
Class names helper (из shadcn/ui).

Объединяет классы с поддержкой условий.

**Пример**:
```typescript
cn('base-class', isActive && 'active-class', 'another-class')
```

#### `formatDate(date: Date): string`
Форматирует дату в читаемый вид.

**Формат**: "12 января 2026"

#### `clamp(value, min, max): number`
Ограничивает значение диапазоном.

---

## Принципы

- **Чистые функции**: Нет побочных эффектов
- **Immutability**: Не мутируем входные данные
- **Типизация**: Строгие TypeScript типы
- **Тестируемость**: Легко покрыть unit-тестами

## Использование в компонентах

```typescript
import { normalize } from '@/lib/normalization'
import { calculateTotalScore } from '@/lib/calculations'
import { saveProjects, loadProjects } from '@/lib/storage'

// В React компоненте или Zustand store
```

## Для AI-ассистентов

- Все функции документированы JSDoc
- Формулы приведены в комментариях
- Примеры использования в описании
- Логика нормализации изолирована от UI
