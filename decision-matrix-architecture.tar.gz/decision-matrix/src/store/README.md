# src/store

Zustand store для глобального состояния приложения.

## Почему Zustand?

- Проще Redux (меньше boilerplate)
- Хуки из коробки
- TypeScript friendly
- Middleware для localStorage
- Devtools поддержка

## Файлы

### `index.ts`
**Главный store приложения.**

## Store Structure

```typescript
interface AppState {
  // Data
  projects: Project[]
  currentProjectId: string | null
  
  // Actions
  // Projects
  createProject: (name: string, description?: string) => void
  deleteProject: (id: string) => void
  updateProject: (id: string, updates: Partial<Project>) => void
  setCurrentProject: (id: string | null) => void
  
  // Criteria
  addCriterion: (projectId: string, criterion: Omit<Criterion, 'id'>) => void
  updateCriterion: (projectId: string, criterionId: string, updates: Partial<Criterion>) => void
  deleteCriterion: (projectId: string, criterionId: string) => void
  
  // Alternatives
  addAlternative: (projectId: string, alternative: Omit<Alternative, 'id'>) => void
  updateAlternative: (projectId: string, altId: string, updates: Partial<Alternative>) => void
  deleteAlternative: (projectId: string, altId: string) => void
  
  // Import/Export
  exportProject: (projectId: string) => string
  importProject: (jsonString: string) => void
  
  // Calculations
  recalculateScores: (projectId: string) => void
  
  // Persistence
  loadFromStorage: () => void
  saveToStorage: () => void
}
```

## Детали реализации

### Создание проекта

```typescript
createProject: (name, description) => {
  const newProject: Project = {
    id: generateId(),
    name,
    description,
    createdAt: new Date(),
    updatedAt: new Date(),
    criteria: [],
    alternatives: []
  }
  
  set(state => ({
    projects: [...state.projects, newProject],
    currentProjectId: newProject.id
  }))
  
  get().saveToStorage()
}
```

**Логика**:
1. Генерим UUID
2. Создаём объект проекта
3. Добавляем в массив
4. Делаем его текущим
5. Сохраняем в localStorage

### Добавление критерия

```typescript
addCriterion: (projectId, criterion) => {
  const newCriterion: Criterion = {
    ...criterion,
    id: generateId()
  }
  
  set(state => ({
    projects: state.projects.map(p => 
      p.id === projectId
        ? { ...p, criteria: [...p.criteria, newCriterion], updatedAt: new Date() }
        : p
    )
  }))
  
  get().saveToStorage()
}
```

**Логика**:
1. Добавляем ID к критерию
2. Находим проект
3. Добавляем критерий в массив
4. Обновляем updatedAt
5. Сохраняем

### Пересчёт рейтингов

```typescript
recalculateScores: (projectId) => {
  set(state => ({
    projects: state.projects.map(p => {
      if (p.id !== projectId) return p
      
      const updatedAlternatives = p.alternatives.map(alt => ({
        ...alt,
        normalizedScores: calculateNormalizedScores(alt, p.criteria),
        totalScore: calculateTotalScore(alt, p.criteria)
      }))
      
      return {
        ...p,
        alternatives: updatedAlternatives,
        updatedAt: new Date()
      }
    })
  }))
  
  get().saveToStorage()
}
```

**Когда вызывается**:
- После изменения критерия (вес, параметры)
- После изменения значения альтернативы
- После добавления/удаления критерия

**Оптимизация**: Можно пересчитывать только изменённые альтернативы, но для MVP пересчитываем все.

### Persistence

```typescript
// При инициализации store
const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      projects: [],
      currentProjectId: null,
      
      // ... actions
      
      loadFromStorage: () => {
        const projects = loadProjects()
        set({ projects })
      },
      
      saveToStorage: () => {
        saveProjects(get().projects)
      }
    }),
    {
      name: 'decision-matrix-storage',
      partialize: (state) => ({ 
        projects: state.projects,
        currentProjectId: state.currentProjectId 
      })
    }
  )
)
```

**Конфиг**:
- `name`: Ключ в localStorage
- `partialize`: Что сохранять (исключаем временные данные)

## Selectors (computed values)

Для производных данных создаём селекторы:

```typescript
// В компоненте
const currentProject = useStore(state => 
  state.projects.find(p => p.id === state.currentProjectId)
)

const rankedAlternatives = useStore(state => {
  const project = state.projects.find(p => p.id === state.currentProjectId)
  if (!project) return []
  return rankAlternatives(project.alternatives, project.criteria)
})
```

## Использование в компонентах

```typescript
import { useStore } from '@/store'

function ProjectList() {
  const projects = useStore(state => state.projects)
  const createProject = useStore(state => state.createProject)
  const setCurrentProject = useStore(state => state.setCurrentProject)
  
  return (
    <div>
      {projects.map(p => (
        <button key={p.id} onClick={() => setCurrentProject(p.id)}>
          {p.name}
        </button>
      ))}
      <button onClick={() => createProject('New Project')}>
        + Create
      </button>
    </div>
  )
}
```

## Оптимизация ре-рендеров

Zustand автоматически оптимизирует, но можно ещё:

```typescript
// Подписка на конкретные поля
const projectName = useStore(state => 
  state.projects.find(p => p.id === id)?.name
)

// Shallow comparison
import { shallow } from 'zustand/shallow'

const { projects, createProject } = useStore(
  state => ({ projects: state.projects, createProject: state.createProject }),
  shallow
)
```

## Middleware

### DevTools

```typescript
import { devtools } from 'zustand/middleware'

const useStore = create<AppState>()(
  devtools(
    persist(
      // ... store
    )
  )
)
```

Открывает Redux DevTools для дебага.

### Logger (для разработки)

```typescript
const log = (config) => (set, get, api) =>
  config(
    (...args) => {
      console.log('  applying', args)
      set(...args)
      console.log('  new state', get())
    },
    get,
    api
  )

const useStore = create(log(/* ... */))
```

## Тестирование

```typescript
import { renderHook, act } from '@testing-library/react'
import { useStore } from './index'

test('creates project', () => {
  const { result } = renderHook(() => useStore())
  
  act(() => {
    result.current.createProject('Test Project')
  })
  
  expect(result.current.projects).toHaveLength(1)
  expect(result.current.projects[0].name).toBe('Test Project')
})
```

## Для AI-ассистентов

- Store следует принципу single source of truth
- Все мутации через actions (не прямое изменение state)
- Actions автоматически сохраняют в localStorage
- Пересчёт рейтингов выполняется лениво (только когда нужно)
- TypeScript гарантирует типобезопасность всех операций

## Альтернативы (если захочется потом)

- **Redux Toolkit**: Если нужна более сложная логика
- **Jotai/Recoil**: Если нужна атомарность
- **MobX**: Если хочется observables

Но для MVP Zustand — оптимальный выбор.
