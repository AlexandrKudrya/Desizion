# src/types

TypeScript типы и интерфейсы для всего приложения.

## Файлы

### `index.ts`
Основные типы данных приложения. Экспортирует все типы для использования в других модулях.

**Основные типы:**

#### `NormalizationType`
Enum типов нормализации:
- `LINEAR` - линейная (больше = лучше)
- `INVERSE_LINEAR` - обратная линейная (меньше = лучше)
- `THRESHOLD` - пороговая (с критической границей)
- `EXPONENTIAL` - экспоненциальная (убывающая важность)
- `CATEGORICAL` - категориальная (фиксированные значения)

#### `Criterion`
Критерий оценки альтернатив.

**Поля:**
```typescript
{
  id: string                      // UUID
  name: string                    // Название (например, "Цена")
  weight: number                  // Вес 0-1 (сумма всех = 1.0)
  normType: NormalizationType     // Тип нормализации
  params: NormalizationParams     // Параметры для нормализации
  description?: string            // Опциональное описание
}
```

#### `NormalizationParams`
Параметры нормализации, зависят от типа:

**Для LINEAR / INVERSE_LINEAR:**
```typescript
{
  min: number      // Минимальное значение
  max: number      // Максимальное значение
}
```

**Для THRESHOLD:**
```typescript
{
  min: number       // Минимум
  max: number       // Максимум (критическая граница)
  threshold1: number // Порог идеального значения
}
```

**Для EXPONENTIAL:**
```typescript
{
  min: number
  max: number
  threshold1: number  // Точка начала экспоненциального спада
  threshold2: number  // Коэффициент спада (k в exp(-k*x))
}
```

**Для CATEGORICAL:**
```typescript
{
  categories: CategoryMapping[]  // Массив категорий
}
```

#### `CategoryMapping`
Мапинг категории на численное значение:
```typescript
{
  label: string   // Название категории (например, "Большой застеклённый")
  value: number   // Нормализованное значение 0-1
}
```

#### `Alternative`
Альтернатива для оценки.

**Поля:**
```typescript
{
  id: string                           // UUID
  name: string                         // Название (например, "Квартира на Приморской")
  description?: string                 // Опциональное описание
  values: Record<string, any>          // Оценки: criterionId -> значение
  normalizedScores?: Record<string, number>  // Нормализованные оценки (авто-расчёт)
  totalScore?: number                  // Итоговый рейтинг (авто-расчёт)
}
```

**Примечание**: `values` может содержать:
- Числа для числовых критериев
- Строки для категориальных критериев
- `null` или `undefined` для незаполненных

#### `Project`
Проект оценки (главная сущность).

**Поля:**
```typescript
{
  id: string              // UUID
  name: string            // Название проекта
  description?: string    // Описание
  createdAt: Date        // Дата создания
  updatedAt: Date        // Дата последнего обновления
  criteria: Criterion[]  // Массив критериев
  alternatives: Alternative[]  // Массив альтернатив
}
```

## Использование

```typescript
import { Project, Criterion, Alternative, NormalizationType } from '@/types'

const criterion: Criterion = {
  id: 'crit-1',
  name: 'Цена',
  weight: 0.2,
  normType: NormalizationType.THRESHOLD,
  params: {
    min: 40000,
    max: 50000,
    threshold1: 45000
  }
}
```

## Валидация

Для валидации данных используется Zod (см. `src/lib/validation.ts`).

## Примечания для AI

- Все ID генерируются как UUID v4
- Веса критериев должны в сумме давать 1.0 (проверка на UI)
- `normalizedScores` и `totalScore` рассчитываются автоматически и не сохраняются в localStorage
- При импорте из JSON старые версии могут не иметь некоторых полей - нужна миграция
